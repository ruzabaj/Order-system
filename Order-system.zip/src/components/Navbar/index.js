import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {
    faHome,
    faReceipt
} from '@fortawesome/free-solid-svg-icons'
import "../../scss/navbar.scss";
import { Link, useNavigate } from 'react-router-dom';
import { FiRefreshCcw } from "react-icons/fi";
import { IoPeopleOutline } from "react-icons/io5";
import { TbReportSearch } from "react-icons/tb";
const Navbar = () => {
    let navigate = useNavigate();

    const logoutUser = () => {
        localStorage.removeItem('token');
        navigate("/")
    }
    return (
        <nav>
            <div>
                <div className='navbar-icons'>
                    <Link to="/home" >
                        <FontAwesomeIcon icon={faHome} />
                    </Link>
                </div>
                <label>Home</label>

            </div>
            <div>
                <div className='navbar-icons'>
                    <Link to="/report">
                        <TbReportSearch className='nav-icon' />
                    </Link>
                </div>
                <label>Report</label>
            </div>
            <div>
                <div className='navbar-icons' onClick={() => window.location.reload(false)}>
                    <FiRefreshCcw />
                </div>
                <label>Refresh</label>
            </div>
            <div>
                <div className='navbar-icons' onClick={logoutUser}>
                    <IoPeopleOutline />
                </div>
                <label>Logout</label>
            </div>
        </nav>
    )
}

export default Navbar
