import React from 'react'

const DatePickerEnd = () => {
  return (
    <div>DatePickerEnd</div>
  )
}

export default DatePickerEnd