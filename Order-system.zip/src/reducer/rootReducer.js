import { combineReducers } from "redux";

